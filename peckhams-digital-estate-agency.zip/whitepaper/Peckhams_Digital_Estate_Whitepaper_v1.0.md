# Peckhams Digital Estate Agency - Whitepaper v1.0
## Section 1: Mike NFT Collection
The core NFT collection, known as "Mike", features 2,500 unique characters minted over 30 days. Key traits and functions include:

- Mint Rules:
  - Max 2 mints per wallet per day
  - 7-day whitelist period
  - Public access for the remaining 23 days
  - Fixed price: 41,667 ROOT per NFT (~$250 USD)

- Ownership Rights:
  - Full personal and commercial rights for each holder
  - Metadata revealed at mint
  - Traits and data permanently locked

- Gameplay Access & Staking:
  - Mike NFTs are required to participate in the crafting game
  - Must be staked for 30 days before earning rewards
  - Staked Mike NFTs earn 50% of the mint price over 12 months (APY structure)

- Accessory Linkage:
  - Each Mike NFT includes one tier-matched accessory from the PCK100 list (if available)
  - Accessory traits correspond to in-game advantage or story role
## Section 2: Level 0 NFTs
These are the foundational resources used to unlock Tier 1 items. There are 5 Level 0 NFTs:

- Gold
- Ooze
- Gems
- Stone
- Alloy

- Token Price: 1,000,000 FLAME tokens each (burned upon use)
- Access: Purchasable via liquidity pools
- Gameplay Role: Required to begin crafting PCK100 item recipes
## Section 3: PCK100 – The 100 Unlockable Items
This is the main interactive layer of the game.

- Structure:
  - 10 items per tier
  - Tiers 1–10, increasing in rarity
  - Tier 0 items (Level 0 NFTs) are used in 5-slot combinations to unlock items

- Game Mechanics:
  - Players guess secret recipes
  - Each correct guess yields:
    - An NFT from that tier
    - 5,000 ROOT reward
    - Unlock of the next-tier item

- Rarity & APY Eligibility:
  - Tiers 1–7: NFTs only
  - Tiers 8–10: NFTs + APY earning rights
  - Tier 10: Only 10 NFTs exist (first correct solvers), each earns APY and a 100,000 ROOT grand prize

- NFT Supply by Tier:
  - Tier 1 = 1000
  - Tier 2 = 900
  - Tier 3 = 800
  - Tier 4 = 600
  - Tier 5 = 500
  - Tier 6 = 60
  - Tier 7 = 70
  - Tier 8 = 80
  - Tier 9 = 90
  - Tier 10 = 10
## Section 4: Bonus NFT
- Eligibility:
  - Awarded for being among the first 50 to solve a recipe in Tier 3 or higher
  - Max 10 Bonus NFTs per player
  - Only 5 per player can be staked for APY

- Supply: Unlimited (based on player achievement, not pre-minted)
## Section 5: Smart Contracts & Tokenomics
- Token: FLAME (ERC-20 on Root Network)
  - Total supply: 1,000,000
  - Utility: NFT purchases, recipe crafting, reward mechanism

- LP Pools:
  - Gold:Ooze
  - Gold:Gems
  - Gems:Alloy
  - Alloy:Gold
  - Alloy:Ooze
  - Remaining pairs to be deployed post-launch

- Staking Rules:
  - Mike NFTs: Stake to earn APY from mint pool
  - Tier 8–10 NFTs: Stake to earn from game revenue pool
  - Must be staked for 30 days to activate yield
## Section 6: Web & UX Design
- Interface Style: Inspired by Elementerra.io
  - Cream-toned UI
  - 5-slot drag-and-drop crafting panel
  - MetaMask integration for all Web3 actions

- Interaction Flow:
  - Connect wallet
  - Select Level 0 NFTs
  - Submit recipe
  - Receive feedback (success/fail)
  - View unlocked NFT + lore if successful
## Section 7: Legal Notice
Effective Date: [Insert Launch Date]
By accessing or using this platform, you agree to the following:

- No Financial Advice:
  All features are for entertainment and utility. Rewards are not investment products. Participation is at your own risk.

- Staking Disclaimer:
  APY rewards are subject to in-game economics and are not guaranteed.

- Wallet Responsibility:
  Users are responsible for their own wallet security and key management.

- Jurisdiction:
  You are responsible for compliance with your local laws.
## Section 8: Privacy Policy
- Wallet Data:
  We use wallet addresses as pseudonymous IDs and track interactions on-chain.

- No Personal Info Required:
  We do not collect PII unless voluntarily submitted (e.g., via forms).

- Cookies:
  Minimal use of analytics. No invasive tracking or fingerprinting.

- Third-Party Wallets:
  Integration with MetaMask and other Web3 providers. We do not store private keys.

- Security:
  Industry-standard off-chain protection, but blockchain risks remain.