# 08 Whitepaper Index

This document outlines the core pillars of the project:
1. Mike NFTs - access, staking, APY
2. Level 0 Items - crafting inputs
3. Bonus NFTs - staking multipliers + scarcity
4. PCK100 - recipe-based progression system
5. Contracts - full Root-compatible infrastructure
6. UX - Elementerra-style gameplay interface
7. Legal - full policy, ownership, and PII protections